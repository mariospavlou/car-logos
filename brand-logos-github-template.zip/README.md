# brand-logos (GitHub Actions template)

**What it does**
- Parses `assets/brands.html` for `(brand, image-url)` pairs.
- Downloads images, saves SEO filenames (lowercase-hyphen).
- Creates `brand-logos.zip` and uploads it as an artifact with `_manifest.csv`.

**How to use**
1. Create a new GitHub repo (public or private).
2. Upload this folder's contents.
3. Go to **Actions** → **Build brand-logos.zip** → **Run workflow**.
4. When the job finishes, download the **brand-logos** artifact (contains `brand-logos.zip`).

**Edit / Update**
- Replace or update `assets/brands.html` with your snippet and push; the workflow will run on push.

**Notes**
- Filenames are slugs derived from `<span>Brand</span>` (e.g., `aston-martin.jpg`).
- Any failed downloads create `.FAILED.txt` files for visibility.
